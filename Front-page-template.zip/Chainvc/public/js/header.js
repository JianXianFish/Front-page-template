$(function () {
    $('#menu-btn').on('click',function () {
        if($(this).hasClass('open')){
            $(this).removeClass('open');
            $('#nav-box').hide();
        }else{
            $(this).addClass('open');
            $('#nav-box').show();
        }
    });
    $('.open-btn').on('click',function () {
        var $this = $(this);
        console.log("123")
        var $thisparent = $this.parents('.first-menu');
        if($thisparent.hasClass('open')){
            $thisparent.removeClass('open');
            $thisparent.find('.second-menu').hide();
            console.log("321")
        }else {
            $thisparent.addClass('open');
            $thisparent.find('.second-menu').show();
        }
    });
    $(window).resize(function () {
        var width = $(this).width();
        if(width>780){
            $('#nav-box').show();
            $('#menu-btn').removeClass('open');
        }else {
            $('#nav-box').hide();
            $('#menu-btn').removeClass('open');
        }

    })
})