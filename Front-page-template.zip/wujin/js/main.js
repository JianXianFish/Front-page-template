console.log("%c                           ", "background-image: url(https://raw.githubusercontent.com/ZHAO-Shaofeng/Related-considerations-for-HTML-CSS-JS/master/github-img/xchl-logo.png);background-repeat: no-repeat;padding-top: 110px;");
console.log("%c技术支持：深圳市小草互联网科技有限公司，专注前端外包、美工外包。\n联系电话：13823771028\n淘宝店：https://shop269081662.taobao.com\n欢迎联系QQ/微信：364243821；并对我们的产品提出宝贵的意见和建议。\n为您服务，我们不胜荣幸！\n\n1.  根目录文件说明：\n    css | fonts | images | js | 页面（最终存放设计界面图片）；\n\n2.  所有icon图标一律引用阿里iconfont的线上图标。\nps：客户如需转交iconfont项目所有权，请与项目交付3天内联系我司。\nediter：赵少锋", "color: #0465c2;font-family: '微软雅黑';");

// back to top
function goTop() {
    $('html,body').animate({'scrollTop': 0}, 1000);
}

$(window).scroll(function () {
    if ($(document).scrollTop() >= 200) {
        $('#backtop').addClass("show");
    } else {
        $('#backtop').removeClass("show");
    }
});
// mobile header nav dropdown-menu
$(document).on("click", ".mobile-navbtn", function (e) {
    $(this).toggleClass("open");
    $(this).parents("a").next(".dropdown-menu").toggleClass("open");
    e.preventDefault();
});

//swiper API move to -> http://www.swiper.com.cn/
new Swiper('#banner_swiper', {
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
        renderBullet: function (index, className) {
            let num = index + 1;
            if (num < 10) {
                num = '0' + num;
            }
            return '<span class="' + className + ' pagination_click">' + num + '</span>';
        }
    }
});

new Swiper('.product_swiper', {
    slidesPerView: 5,	            //一屏显示多少个
    slidesPerColumn: 2,	          //显示2行
    spaceBetween: 10,	            //每个之间的间距
    slidesPerColumnFill: 'row',
    breakpoints: {		            //响应式设置
        1200: {
            slidesPerView: 4
        },
        992: {
            slidesPerView: 3
        },
        768: {
            slidesPerView: 2,
            slidesPerColumn: 1	          //显示2行
        },
        475: {
            slidesPerView: 1,
            slidesPerColumn: 1
        }
    }
});

new Swiper('#case_swiper', {
    pagination: {
        el: '.swiper-pagination',
    },
    slidesPerView: 5,	            //一屏显示多少个
    spaceBetween: 20,
    breakpoints: {		            //响应式设置
        1200: {
            slidesPerView: 4
        },
        992: {
            slidesPerView: 3
        },
        768: {
            slidesPerView: 2
        },
        475: {
            slidesPerView: 1
        }
    }
});

new Swiper('#product_tab_swiper', {
    slidesPerView: 4,	            //一屏显示多少个
    spaceBetween: 35,
    breakpoints: {		            //响应式设置
        1200: {
            slidesPerView: 4
        },
        992: {
            slidesPerView: 3
        },
        768: {
            slidesPerView: 2
        },
        475: {
            slidesPerView: 1
        }
    }
});

let factory_swiper = new Swiper('#factory_swiper', {
    navigation: {
        nextEl: '.factory_swiper_next',
        prevEl: '.factory_swiper_prev',
    },
    slidesPerView: 4,
    on: {
        click: function (e) {
            $(factory_swiper.clickedSlide).addClass('factory_active');
            $(factory_swiper.clickedSlide).siblings().removeClass('factory_active');
            $('#image_box .img_box').removeClass('active');
            $('#image_box .img_box').eq(factory_swiper.clickedIndex).addClass('active');
        }
    },
    spaceBetween: 10
});


$(function () {
    resizeBox();
    $(window).resize(function (e) {
        let width = $(this).width();
        if (width > 1199) {
            resizeBox();
        } else {
            $('.product_tab_box').attr('style', 'margin-right:0px');
        }
    });

    function resizeBox() {
        let width = $(window).width();
        let margin = width / 2 - 600;
        $('.product_tab_box').attr('style', 'margin-right:-' + (margin + 20) + 'px');
    }

    let scrollSpa = {
        activeIndex: 0,
        maxIndex: 0,
        target: null,
        max: 0,
        min: 0,
        scroll: 0,
        navigation: {
            nextEl: '.scroll-next',
            prevEl: '.scroll-prev'
        },
        init(id, param) {
            this.target = $(id);
            let $target = this.target;
            this.maxIndex = $target.find('.tab_list_slide').length;
            if (param) {
                this.navigation.nextEl = param.navigation.nextEl;
                this.navigation.prevEl = param.navigation.prevEl;
            }
            this.scrollGun();
            this.resize();
            $(window).resize(e => {
                this.resize();
                let thisBox = this.target.find('#tab_list_wrapper');
                this.scroll = 0;
                thisBox.attr('style', 'transform: translateX(' + 0 + 'px);transition: all .3s;');
            });
            this.initNavigation();
        },
        initNavigation() {
            let $this = this;
            let $target = this.target;
            let $nextEl = $target.find(this.navigation.nextEl);
            if (!$nextEl[0]) {
                $nextEl = $(this.navigation.nextEl);
            }
            let $prevEl = $target.find(this.navigation.prevEl);
            if (!$prevEl[0]) {
                $prevEl = $(this.navigation.prevEl);
            }
            $nextEl.click(function (e) {
                let activeIndex = $this.activeIndex;
                let maxIndex = $this.maxIndex;
                if (activeIndex < maxIndex - 1) {
                    $this.activeIndex++;
                    $this.productNext();
                    $target.find('.tab_list_slide').removeClass('tab_active');
                    $target.find('.tab_list_slide').eq($this.activeIndex).addClass('tab_active');
                }
            });
            $prevEl.click(function (e) {
                let activeIndex = $this.activeIndex;
                if (activeIndex > 0) {
                    $this.activeIndex--;
                    $this.productPrev();
                    $target.find('.tab_list_slide').removeClass('tab_active');
                    $target.find('.tab_list_slide').eq($this.activeIndex).addClass('tab_active');
                }
            });
        },
        productNext() {
            let $scroll_li = this.target.find('.tab_list_slide');
            let windthC = $scroll_li.width() + 35;
            let $wrapper = this.target.find('#tab_list_wrapper');
            let scroll = parseInt($wrapper.attr('data-scroll')) || 0;
            let width = this.target.width();
            if ((scroll + width) < (windthC * this.activeIndex) + windthC) {
                let huadong = (windthC * this.activeIndex) - width + windthC;
                this.scroll = -huadong;
                $wrapper.attr('style', 'transform: translateX(' + -huadong + 'px);transition: all .3s;');
            }
        },
        productPrev() {
            let $scroll_li = this.target.find('.tab_list_slide');
            let windthC = $scroll_li.width() + 35;
            let $wrapper = this.target.find('#tab_list_wrapper');
            let scroll = parseInt($wrapper.attr('data-scroll')) || 0;
            let width = this.target.width();
            let maxWidth = this.maxIndex * windthC;
            if ((maxWidth - width + windthC) > (windthC * this.activeIndex) + windthC) {
                let huadong = (windthC * this.activeIndex);
                this.scroll = -huadong;
                $wrapper.attr('style', 'transform: translateX(' + -huadong + 'px);transition: all .3s;');
            }
        },
        resize() {
            let $scroll_li = this.target.find('.tab_list_slide');
            let windthC = $scroll_li.width() + 35;
            this.min = 0;
            this.max = $scroll_li.length * windthC;
            this.max -= this.target.width();
        },
        scrollGun() {
            let isCheck = true;
            let scroll_box = this.target;
            let $this = this;
            if (scroll_box) {
                scroll_box.bind('mousedown touchstart', e => {
                    let scroll_box_wrapper = scroll_box.find('#tab_list_wrapper');
                    let start = e.screenX;
                    isCheck = false;
                    let scroll = $this.scroll;
                    scroll_box.bind('mousemove', er => {
                        if (!isCheck) {
                            let end = er.screenX;
                            $this.scroll = scroll - (start - end);

                            scroll_box_wrapper.attr('style', 'transform: translateX(' + $this.scroll + 'px);');
                        }
                    });
                    scroll_box.bind('mouseup touchmove', e => {
                        isCheck = true;
                        let scroll2 = $this.scroll;
                        if (scroll2 > $this.min) {
                            $this.scroll = 0;
                            scroll_box_wrapper.attr('style', 'transform: translateX(' + 0 + 'px);transition: all .3s;');
                        } else if (-scroll2 > $this.max) {
                            $this.scroll = -$this.max;
                            scroll_box_wrapper.attr('style', 'transform: translateX(' + -$this.max + 'px);transition: all .3s;');
                        }
                    });
                    $(document).bind('mouseup touchend', e => {
                        isCheck = true;
                        let scroll2 = $this.scroll;
                        if (scroll2 > $this.min) {
                            $this.scroll = 0;
                            scroll_box_wrapper.attr('style', 'transform: translateX(' + 0 + 'px);transition: all .3s;');
                        } else if (-scroll2 > $this.max) {
                            $this.scroll = -$this.max;
                            scroll_box_wrapper.attr('style', 'transform: translateX(' + -$this.max + 'px);transition: all .3s;');
                        }
                    });
                });
            }
        }
    };
    scrollSpa.init('#tab_list_my', {
        navigation: {
            nextEl: '.product_next',
            prevEl: '.product_prev'
        }
    });

});