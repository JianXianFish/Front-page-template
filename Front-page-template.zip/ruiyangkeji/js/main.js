// back to top
function goTop() {
  $('html,body').animate({ 'scrollTop': 0 }, 1500);
}
$(window).scroll(function(){
  if ($(document).scrollTop() >= 200) {
    $('#backtop').addClass("show");
  } else {
    $('#backtop').removeClass("show");
  }
});

// mobile header nav dropdown-menu
$(document).on("click", ".mobile-navbtn", function(e){
  $(this).toggleClass("open");
  $(this).parents("a").next(".dropdown-menu").toggleClass("open");
  e.preventDefault();
})

jQuery(".slideTxtBox").slide({trigger:"click"});

//swiper API move to -> http://www.swiper.com.cn/
var mySwiper1 = new Swiper('#swipwer1', {
    autoplay: false,//可选选项，自动滑动
    pagination: {
        el: '#swipwer1-pagination',
        bulletElement : 'li',
        clickable :true
    }
})
var bannerSwiper = new Swiper('#banner-swiper', {
    slidesPerView: 1,
    autoplay: {		//自动播放
      delay: 3000,	//间隔时间
      disableOnInteraction: false,	//用户操作swiper之后，是否禁止autoplay。
    },
    pagination: {
        el: '#banner-pagination',
        clickable :true
    },
    breakpoints: {
      1200: {
        slidesPerView: 1
      },
      992: {
        slidesPerView: 1
      },
      768: {
        slidesPerView: 1
      }
    }
})

var successfulSwiper = new Swiper('#succses-swiper', {
  autoplay: false,
  slidesPerView: 1,
  navigation: {	
    nextEl: '.successful-next',
    prevEl: '.successful-prev'
  },
  pagination: {
    el: '#successful-pagination',
    clickable :true
  },
  breakpoints: {
    1200: {
      slidesPerView: 1
    },
    992: {
      slidesPerView: 1
    },
    768: {
      slidesPerView: 1
    }
  }
})

var productsfulSwiper = new Swiper('.products-swiper', {
  autoplay: false,
  slidesPerView: 3,
  slidesPerColumn: 2,
  spaceBetween: 10,
  pagination: {
    el: '.products-pagination',
    clickable :true
  },
  breakpoints: {
    1200: {
      slidesPerView: 3,
      slidesPerColumn: 2,
      spaceBetween: 10
    },
    992: {
      slidesPerView: 3,
      slidesPerColumn: 1,
      spaceBetween: 10
    },
    768: {
      slidesPerView: 2,
      slidesPerColumn: 1,
      spaceBetween: 10
    },
    500: {
      slidesPerView: 1,
      slidesPerColumn: 1,
      spaceBetween: 10
    }
  }
})

var whySwiper = new Swiper('#why-swiper', {
  autoplay: false,
  slidesPerView: 2,
  spaceBetween: 35,
  breakpoints: {
    500: {
      slidesPerView: 1
    }
  },
  pagination: {
    el: '#why-pagination',
    clickable :true
  }
})

var newsSwiper = new Swiper('#news-swiper', {
  autoplay: false,
  slidesPerView: 3,
  spaceBetween: 35,
  pagination: {
    el: '#news-pagination',
    clickable :true
  },
  breakpoints: {
    1200: {
      slidesPerView: 3,
      spaceBetween: 35
    },
    992: {
      slidesPerView: 2,
      spaceBetween: 35
    },
    768: {
      slidesPerView: 2,
      spaceBetween: 35
    },
    500: {
      slidesPerView: 1
    }
  }
})

var faqswiper = new Swiper('#faq-swiper', {
  autoplay: false,
  slidesPerView: 3,
  spaceBetween: 35,
  pagination: {
    el: '#faq-pagination',
    clickable :true
  },
  breakpoints: {
    1200: {
      slidesPerView: 3,
      spaceBetween: 35
    },
    992: {
      slidesPerView: 2,
      spaceBetween: 35
    },
    768: {
      slidesPerView: 1,
      spaceBetween: 35
    }
  }
})

var aboutSwiper = new Swiper('#about-swiper', {
  autoplay: false,
  slidesPerView: 4,
  spaceBetween: 35,
  pagination: {
    el: '#about-pagination',
    clickable :true
  },
  breakpoints: {
    1200: {
      slidesPerView: 4,
      spaceBetween: 35
    },
    992: {
      slidesPerView: 3,
      spaceBetween: 35
    },
    768: {
      slidesPerView: 2,
      spaceBetween: 35
    },
    450: {
      slidesPerView: 1
    }
  }
})

var certificateSwiper = new Swiper('#who-banner', {
    autoplay: false,
    slidesPerView: 2,
    spaceBetween: 19,
    navigation: {	
      nextEl: '#certificate-next',
      prevEl: '#certificate-prev'
    },
    pagination: {
      el: '#certificate-pagination',
      clickable :true
    },
    breakpoints: {
      1500: {
        slidesPerView: 2,
        spaceBetween: 19
      },
      1200: {
        slidesPerView: 2,
        spaceBetween: 35
      },
      992: {
        slidesPerView: 2,
        spaceBetween: 17
      },
      768: {
        slidesPerView: 2,
        spaceBetween: 17
      },
      450: {
        slidesPerView: 1,
        spaceBetween: 17
      }
    }
})
var chooseSwiper = new Swiper('#choose-swiper', {
    autoplay: false,
    slidesPerView: 3,
    centeredSlides : true,
    slideToClickedSlide: true,
    spaceBetween: 140,
    pagination: {
        el: '.choose-pagination',
        clickable :true,
    },
    breakpoints: {
      1200: {
        slidesPerView: 2,
        spaceBetween: 0
      },
      992: {
        slidesPerView: 1,
        spaceBetween: 0
      }
    }
})




"use strict"; !
function(t, i) {
    var e = {
        id: "#cardArea",
        sid: ".card-item"
    };
    i.fn.cardArea = function(t) {
        var t = i.extend({},
        e, t);
        return this.each(function() {
            var e = i(t.id),
            n = e.find(t.sid);
            n.on("mouseenter",
            function() {
                i(this).addClass("active").siblings().removeClass("active")
            })
        })
    };
} (window, jQuery);
$("#cardArea").cardArea();
//mouseenter