// back to top
function goTop() {
    $('html,body').animate({ 'scrollTop': 0 }, 1500);
}
$(window).scroll(function(){
    if ($(document).scrollTop() >= 200) {
        $('#backtop').addClass("show");
    } else {
        $('#backtop').removeClass("show");
    }
});

// mobile header nav dropdown-menu
$(document).on("click", ".mobile-navbtn", function(e){
    $(this).toggleClass("open");
    $(this).parents("a").next(".sub-menu").toggleClass("open");
    e.preventDefault();
});

jQuery("#productainer").slide({effect:"left", titCell: ".titCell"});

//swiper API move to -> http://www.swiper.com.cn/
var bannerSwiper = new Swiper ('#banner-swiper', {
    autoplay: true,
    autoplayDisableOnInteraction : false,
    initialSlide: 1,
    // loop: true,
    pagination: {
        el: '.swiper-pagination',
        clickable :true
    },
    navigation: {
        nextEl: '.banner.swiper-button-next',
        prevEl: '.banner.swiper-button-prev',
    },
    on: {
        slideChangeTransitionStart: function(){
            var $currents = this.activeIndex;
            var $totals = this.slides.length - 1;
            if($currents == 0) {
                $("#prev_img").hide();
            }else{
                $("#prev_img").show();
                $("#prev_img img").attr("src", $("#banner-swiper .swiper-slide.swiper-slide-prev img")[0].src);
            }
            if($currents == $totals) {
                $("#next_img").hide();
            }else{
                $("#next_img").show();
                $("#next_img img").attr("src", $("#banner-swiper .swiper-slide.swiper-slide-next img")[0].src);

            }
        },
    },
});

var proSwiper = new Swiper ('#pro-swiper', {
    slidesPerView: 4,
    slidesPerColumn: 2,
    spaceBetween: 10,
    observer:true,
    observeParents:true,
    breakpoints: {
        992: {
            slidesPerView: 3,
        },
        767: {
            slidesPerView: 2,
        },
        425: {
            slidesPerView: 1,
            slidesPerColumn: 0,
        }
    },
    navigation: {
        nextEl: '.pro.swiper-button-next',
        // prevEl: '.swiper-button-prev',
    },
});

var advSwiper = new Swiper ('#adv-swiper', {
    slidesPerView: 3,
    spaceBetween: 60,
    swipeHandler : '.swipe-handler',

    breakpoints: {
        1200: {
            slidesPerView: 3,
            spaceBetween: 10,
        },
        992: {
            slidesPerView: 2,
            spaceBetween: 10,
            swipeHandler : '',

        },
        768: {
            slidesPerView: 2,
            spaceBetween: 10,
            swipeHandler : '',
        },
        767: {
            slidesPerView: 1,
            swipeHandler : '',
        }
    },
    pagination: {
        el: '.swiper-pagination',
    },
});
var aboutSwiper = new Swiper ('#about-swiper', {
    slidesPerView: 3,
    spaceBetween: 30,
    swipeHandler : '.swipe-handler',
    breakpoints: {
        1024: {
            spaceBetween: 20,
        },
        425: {
            slidesPerView: 1,
            swipeHandler : '',
        }
    },
    pagination: {
        el: '.swiper-pagination',
    },
});
var patentSwiper = new Swiper ('#patent-swiper', {
    slidesPerView: 4,
    spaceBetween: 17,
    breakpoints: {
        1024: {
            slidesPerView: 3,
        },
        768: {
            slidesPerView: 2,
        },
        767: {
            slidesPerView: 1,
        }
    },
    navigation: {
        nextEl: '.friend.swiper-button-next',
        prevEl: '.friend.swiper-button-prev',
    },
});
var friendSwiper = new Swiper ('#friend-swiper', {
    slidesPerView: 5,
    spaceBetween: 20,
    slidesPerGroup : 5,
    initialSlide: 1,
    breakpoints: {
        1024: {
            slidesPerView: 3,
        },
        768: {
            slidesPerView: 2,
        },
        767: {
            slidesPerView: 1,
        }
    },
    pagination: {
        el: '.link.swiper-pagination',
        clickable :true
    },

});
var caseSwiper = new Swiper ('#case-swiper', {
    slidesPerView: 3,
    spaceBetween: 30,
    swipeHandler : '.swipe-handler',
    breakpoints: {
        1024: {
            swipeHandler : '',
            slidesPerView: 3,
        },
        991: {
            swipeHandler : '',
            slidesPerView: 2,
        },
        767: {
            swipeHandler : '',
            slidesPerView: 1,
        }
    },
    navigation: {
        nextEl: '.case.swiper-button-next',
        prevEl: '.case.swiper-button-prev',
    },
});
var nSwiper = new Swiper ('.new-swiper', {
    slidesPerView: 4,
    spaceBetween: 20,
    observer:true,
    observeParents:true,
    swipeHandler : '.swipe-handler',
    breakpoints: {
        1024: {
            swipeHandler : '',
            slidesPerView: 3,
        },
        768: {
            swipeHandler : '',
            slidesPerView: 2,
        },
        767: {
            swipeHandler : '',
            slidesPerView: 1,
        }
    },
    pagination: {
        el: '.swiper-pagination',
    },

});
// Word number restriction
$(".more-content .desc").each(function () {
    var $content = $(this).text();
    if($content.length > 170) {
        $(this).html($(this).text().substring(0,170) + "...");
    }
});
$(".ett-new .title").each(function () {
    var $content = $(this).text();
    if($content.length > 54) {
        $(this).html($(this).text().substring(0,54) + "...");
    }
});
$(".ett-new .desc").each(function () {
    var $content = $(this).text();
    if($content.length > 104) {
        $(this).html($(this).text().substring(0,104) + "...");
    }
});