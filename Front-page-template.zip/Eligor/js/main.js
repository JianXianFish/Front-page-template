// back to top
function goTop() {
    $('html,body').animate({'scrollTop': 0}, 1500);
}

$(window).scroll(function () {
    if ($(document).scrollTop() >= 200) {
        $('#backtop').addClass("show");
    } else {
        $('#backtop').removeClass("show");
    }
});

// mobile header nav dropdown-menu
$(document).on("click", ".mobile-navbtn", function (e) {
    $(this).toggleClass("open");
    $(this).parents("a").next(".dropdown-menu").toggleClass("open");
    e.preventDefault();
})

//swiper API move to -> http://www.swiper.com.cn/

new Swiper('#top_banner', {
    autoplay: true,//可选选项，自动滑动
    pagination: {
        el: '.banner-pagination',
        clickable: true,
    },
});
new Swiper('.product_banner', {
    autoplay: false,//可选选项，自动滑动
    slidesPerView: 4,
    pagination: {
        el: '.product-pagination',
    },
    observer: true,		            //修改swiper自己或子元素时，自动初始化swiper
    observeParents: true,	        //修改swiper的父元素时，自动初始化swiper
    breakpoints: {		            //响应式设置
        1400: {
            slidesPerView: 3,
            spaceBetween: 35
        },
        992: {
            slidesPerView: 2,
            spaceBetween: 35
        },
        768: {
            slidesPerView: 2,
            spaceBetween: 35
        },
        550: {
            slidesPerView: 1,
            spaceBetween: 35
        }
    }
});

new Swiper('#news_swiper', {
    autoplay: false,//可选选项，自动滑动
    slidesPerView: 4,
    pagination: {
        el: '.news-pagination',
    },
    observer: true,		            //修改swiper自己或子元素时，自动初始化swiper
    observeParents: true,	        //修改swiper的父元素时，自动初始化swiper
    breakpoints: {		            //响应式设置
        1400: {
            slidesPerView: 3,
            spaceBetween: 35
        },
        992: {
            slidesPerView: 2,
            spaceBetween: 35
        },
        768: {
            slidesPerView: 2,
            spaceBetween: 35
        },
        550: {
            slidesPerView: 1,
            spaceBetween: 35
        }
    }
});


var swiper = new Swiper('#bg_swiper', {
    freeMode: true,
    slidesPerView: 'auto',
    scrollbar: {
        el: '.swiper-scrollbar',
    }
});

$('.tab_box').each(function (index) {
    $(this).click(function (e) {
        if (!$(this).hasClass('active')) {
            $(this).siblings().removeClass('active')
            $(this).addClass('active');
            var $product_box = $('.product_content .tab_content');
            $product_box.removeClass('active');
            $product_box.eq(index).addClass('active');
        }
    })
});

$('.hover_item').hover(function (e) {
    $(this).siblings().removeClass('active');
    $(this).addClass('active')
});

$('.click_list_item').click(function (e) {
    var src = $(this).find('.change_img').attr('src');
    $('#change_img').attr('src', src);
});


$(function () {
    var slider = new SliderUnlock("#slider", {
        successLabelTip: "SUCCESS"
    }, function () {
        console.log("验证成功");
    });
    slider.init();
});
