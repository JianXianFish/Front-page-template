// back to top
function goTop() {
  $('html,body').animate({ 'scrollTop': 0 }, 1500);
}
$(window).scroll(function(){
  if ($(document).scrollTop() >= 200) {
    $('#backtop').addClass("show");
  } else {
    $('#backtop').removeClass("show");
  }
});

// mobile header nav dropdown-menu
$(document).on("click", ".mobile-navbtn", function(e){
  $(this).toggleClass("open");
  $(this).parents("a").next(".dropdown-menu").toggleClass("open");
  e.preventDefault();
})

//swiper API move to -> http://www.swiper.com.cn/
var mySwiper1 = new Swiper('#swipwer1', {
    autoplay: false,//可选选项，自动滑动
    pagination: {
        el: '#swipwer1-pagination',
        bulletElement : 'li',
        clickable :true,
    },
})
var newsSwiper = new Swiper('#news-swiper', {
    autoplay: false,
    slidesPerView: 3,
    spaceBetween: 40,
    pagination: {
        el: '.news-pagination',
        clickable :true,
    },
    breakpoints: {
      1200: {
        slidesPerView: 3,
        spaceBetween: 30
      },
      992: {
        slidesPerView: 2,
        spaceBetween: 20
      },
      768: {
        slidesPerView: 1,
        spaceBetween: 20
      }
    }
})
var certificateSwiper = new Swiper('#certificate-swiper', {
    autoplay: false,
    slidesPerView: 5,
    spaceBetween: 20,
    pagination: {
        el: '.certificate-pagination',
        clickable :true,
    },
    breakpoints: {
      1200: {
        slidesPerView: 4,
        spaceBetween: 35
      },
      992: {
        slidesPerView: 3,
        spaceBetween: 35
      },
      768: {
        slidesPerView: 2,
        spaceBetween: 35
      },
      400: {
        slidesPerView: 1,
        spaceBetween: 35
      }
    }
})
var chooseSwiper = new Swiper('#choose-swiper', {
    autoplay: false,
    slidesPerView: 3,
    centeredSlides : true,
    slideToClickedSlide: true,
    // loop : true,
    spaceBetween: 140,
    // slidesOffsetBefore : -70,
    pagination: {
        el: '.choose-pagination',
        clickable :true,
    },
    breakpoints: {
      1200: {
        slidesPerView: 2,
        spaceBetween: 0
      },
      992: {
        slidesPerView: 1,
        spaceBetween: 0
      }
    }
})
var proSwiper = new Swiper('.pro-swiper', {
    autoplay: false,
    slidesPerView: 4,
    spaceBetween: 30,
    noSwiping : true,
    noSwipingClass : 'no-swiper',
    breakpoints: {
        //当宽度小于等于320
        375: {
            slidesPerView: 1,
            spaceBetween: 30
        },
        //当宽度小于等于480
        768: {
            slidesPerView: 2,
            spaceBetween: 30
        },
        //当宽度小于等于640
        992: {
            slidesPerView: 3,
            spaceBetween: 25
        }
    }
})
var proSwiper1 = new Swiper('.pro-swiper1', {
    autoplay: false,
    slidesPerView: 4,
    spaceBetween: 30,
    noSwiping : true,
    noSwipingClass : 'no-swiper',
    breakpoints: {
        //当宽度小于等于320
        375: {
            slidesPerView: 1,
            spaceBetween: 30
        },
        //当宽度小于等于480
        768: {
            slidesPerView: 2,
            spaceBetween: 30
        },
        //当宽度小于等于640
        992: {
            slidesPerView: 3,
            spaceBetween: 25
        }
    }
})
var proitemBanner = new Swiper('.proitem-banner', {
    autoplay: false,
    slidesPerView: 1,
    spaceBetween: 0,
    pagination: {
        el: '.proitem-banner-pagination',
        clickable :true
    }
})


"use strict"; !
function(t, i) {
    var e = {
        id: "#cardArea",
        sid: ".card-item"
    };
    i.fn.cardArea = function(t) {
        var t = i.extend({},
        e, t);
        return this.each(function() {
            var e = i(t.id),
            n = e.find(t.sid);
            n.on("mouseenter",
            function() {
                i(this).addClass("active").siblings().removeClass("active")
            })
        })
    };
} (window, jQuery);
$("#cardArea").cardArea();

$(function () {
    $(".nav-tabs").find("li a").click(function () {
        $(".nav-tabs").find("li").removeClass('active');
        $(this).parents('li').addClass('active');
        $('.tab-conten').find('.tab-pane').removeClass('active');
        var id =  $(this).attr('href');
        console.log(id.substring(1));
        $(".tab-conten").find('.tab-pane[id='+id.substring(1)+']').addClass('active');
        return false;
    })
})