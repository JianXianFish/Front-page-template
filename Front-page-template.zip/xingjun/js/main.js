console.log("%c                           ", "background-image: url(https://raw.githubusercontent.com/ZHAO-Shaofeng/Related-considerations-for-HTML-CSS-JS/master/github-img/xchl-logo.png);background-repeat: no-repeat;padding-top: 110px;");
console.log("%c技术支持：深圳市小草互联网科技有限公司，专注前端外包、美工外包。\n联系电话：13823771028\n淘宝店：https://shop269081662.taobao.com\n欢迎联系QQ/微信：364243821；并对我们的产品提出宝贵的意见和建议。\n为您服务，我们不胜荣幸！\n\n1.  根目录文件说明：\n    css | fonts | images | js | 页面（最终存放设计界面图片）；\n\n2.  所有icon图标一律引用阿里iconfont的线上图标。\nps：客户如需转交iconfont项目所有权，请与项目交付3天内联系我司。\nediter：赵少锋", "color: #0465c2;font-family: '微软雅黑';");
// back to top
function goTop() {
  $('html,body').animate({ 'scrollTop': 0 }, 1000);
}
$(window).scroll(function(){
  if ($(document).scrollTop() >= 200) {
    $('#backtop').addClass("show");
  } else {
    $('#backtop').removeClass("show");
  }
});
// mobile header nav dropdown-menu
$(document).on("click", ".mobile-navbtn", function(e){
  $(this).toggleClass("open");
  $(this).parents("a").next(".dropdown-menu").toggleClass("open");
  e.preventDefault();
})

//swiper API move to -> http://www.swiper.com.cn/