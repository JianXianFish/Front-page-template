console.log("%c                           ", "background-image: url(https://raw.githubusercontent.com/ZHAO-Shaofeng/Related-considerations-for-HTML-CSS-JS/master/github-img/xchl-logo.png);background-repeat: no-repeat;padding-top: 110px;");
console.log("%c技术支持：深圳市小草互联网科技有限公司，专注前端外包、美工外包。\n联系电话：13823771028\n淘宝店：https://shop269081662.taobao.com\n欢迎联系QQ/微信：364243821；并对我们的产品提出宝贵的意见和建议。\n为您服务，我们不胜荣幸！\n\n1.  根目录文件说明：\n    css | fonts | images | js | 页面（最终存放设计界面图片）；\n\n2.  所有icon图标一律引用阿里iconfont的线上图标。\nps：客户如需转交iconfont项目所有权，请与项目交付3天内联系我司。\nediter：赵少锋", "color: #0465c2;font-family: '微软雅黑';");
// back to top
function goTop() {
  $('html,body').animate({ 'scrollTop': 0 }, 1000);
}
$(window).scroll(function(){
  if ($(document).scrollTop() >= 200) {
    $('#backtop').addClass("show");
  } else {
    $('#backtop').removeClass("show");
  }
});
// mobile header nav dropdown-menu
$(document).on("click", ".mobile-navbtn", function(e){
  $(this).toggleClass("open");
  $(this).parents("a").next(".dropdown-menu").toggleClass("open");
  e.preventDefault();
})

//swiper API move to -> http://www.swiper.com.cn/
var banner_Swiper = new Swiper('#banner-swiper', {
    loop: true,
    autoplay: {
      disableOnInteraction: false
    },
    pagination: {
      el: '.banner-pagination',
      clickable :true
    },
});


var sort_Swiper = new Swiper('#sort-swiper',{
  slidesPerView: 4,
  spaceBetween: 0,
  observer: true,
  observeParents: true,
  breakpoints: {
    1200: {
      slidesPerView: 4
    },
    992: {
      slidesPerView: 4
    },
    768: {
      slidesPerView: 3
    },
    400: {
      slidesPerView: 2
    }
  },
  pagination: {                 //分页器
      el: '.sort-pagination',
      clickable :true           //允许点击分页器切换
  },
});

var product_Swiper = new Swiper('#product-swiper',{
  slidesPerView: 6,
  spaceBetween: 25,
  observer: true,
  observeParents: true,
  navigation: {		              //前进后退按钮
    nextEl: '.swiper-btnRight',
    prevEl: '.swiper-btnLeft'
  },
  breakpoints: {		            //响应式设置
    1200: {
      slidesPerView: 4,
      spaceBetween: 35
    },
    992: {
      slidesPerView: 3,
      spaceBetween: 35
    },
    768: {
      slidesPerView: 3,
      spaceBetween: 30
    },
    600: {
      slidesPerView: 2,
      spaceBetween: 20
    },
    400: {
      slidesPerView: 1,
      spaceBetween: 35
    }
  }
});

var choose_Swiper = new Swiper('#choose-swiper',{
  slidesPerView: 2,
  slidesPerColumn: 3,	
  observer: true,
  observeParents: true,
  swipeHandler : '#choose-swiper',
  breakpoints: {		            //响应式设置
    1200: {
      slidesPerView: 2,
      slidesPerColumn: 3
    },
    992: {
      slidesPerView: 2,
      slidesPerColumn: 3
    },
    600: {
      slidesPerView: 1,
      slidesPerColumn: 3,
      swipeHandler : '' 
    },
    400: {
      slidesPerView: 1,
      slidesPerColumn: 3,
      swipeHandler : '' 
    }
  },
  pagination: {                 //分页器
      el: '.choose-pagination',
      clickable :true           //允许点击分页器切换
  },
});

var book_Swiper = new Swiper('#book-swiper1',{
  slidesPerView: 6,
  spaceBetween: 20,
  observer: true,
  observeParents: true,
  navigation: {		              //前进后退按钮
    nextEl: '.swiper1-btnRight',
    prevEl: '.swiper1-btnLeft'
  },
  breakpoints: {		            //响应式设置
    1200: {
      slidesPerView: 5,
      spaceBetween: 20
    },
    992: {
      slidesPerView: 4,
      spaceBetween: 20
    },
    768: {
      slidesPerView: 3,
      spaceBetween: 20
    },
    500: {
      slidesPerView: 2,
      spaceBetween: 15
    }
  }
});
var book_Swiper = new Swiper('#book-swiper2',{
  slidesPerView: 6,
  spaceBetween: 20,
  observer: true,
  observeParents: true,
  navigation: {                 //前进后退按钮
    nextEl: '.swiper2-btnRight',
    prevEl: '.swiper2-btnLeft'
  },
  breakpoints: {                //响应式设置
    1200: {
      slidesPerView: 5,
      spaceBetween: 20
    },
    992: {
      slidesPerView: 4,
      spaceBetween: 20
    },
    768: {
      slidesPerView: 3,
      spaceBetween: 20
    },
    500: {
      slidesPerView: 2,
      spaceBetween: 15
    }
  }
});



var caseSwiper = new Swiper('#case-swiper',{
  slidesPerView:4,
  spaceBetween:30,
  observer: true,
  observeParents: true,
  navigation: {                 //前进后退按钮
    nextEl: '.case-swiper-btnRight',
    prevEl: '.case-swiper-btnLeft'
  },
  breakpoints: {		            //响应式设置
    1200: {
      slidesPerView: 4,
      spaceBetween: 25
    },
    992: {
      slidesPerView: 4,
      spaceBetween: 25
    },
    768: {
      slidesPerView: 4,
      spaceBetween: 25
    },
    400: {
      slidesPerView: 4,
      spaceBetween: 25
 
    }
  }
});
var caseSwiper = new Swiper('#case2-swiper',{
  slidesPerView:1,
  spaceBetween:30,
  observer: true,
  observeParents: true,
  breakpoints: {                //响应式设置
    1200: {
      slidesPerView: 1,
      spaceBetween: 20
    },
    992: {
      slidesPerView: 1,
      spaceBetween: 16
    },
    768: {
      slidesPerView: 1,
      spaceBetween: 16
    },
    400: {
      slidesPerView: 1,
      spaceBetween: 16
 
    }
  },
  navigation: {                 //前进后退按钮
    nextEl: '.case-swiper-btnRight',
    prevEl: '.case-swiper-btnLeft'
  },
});


jQuery(".slideTxtBox").slide({trigger:"click",easing:"swing"});

$(document).on('click', '[name="Certificate"]', function() {
  $('.book-swiper2-button').hide();
  $('.book-swiper1-button').show();
})
$(document).on('click', '[name="Factory"]', function() {
  $('.book-swiper1-button').hide();
  $('.book-swiper2-button').show();
})

//数字递增
var wrapTop = $("#wrap-video").offset().top;
var istrue = true;
$(window).on("scroll",
function() {
    var s = $(window).scrollTop();
    if (s > wrapTop - 580 && istrue) {
        $(".incrementing").each(count);
        function count(a) {
            var b = $(this);
            a = $.extend({},
            a || {},
            b.data("countToOptions") || {});
            b.countTo(a)
        };
        istrue = false;
    };
})
//设置计数
$.fn.countTo = function (options) {
  options = options || {};
  return $(this).each(function () {
  //当前元素的选项
  var settings = $.extend({}, $.fn.countTo.defaults, {
    from:            $(this).data('from'),
    to:              $(this).data('to'),
    speed:           $(this).data('speed'),
    refreshInterval: $(this).data('refresh-interval'),
    decimals:        $(this).data('decimals')
  }, options);
  //更新值
  var loops = Math.ceil(settings.speed / settings.refreshInterval),
      increment = (settings.to - settings.from) / loops;
  //更改应用和变量
  var self = this,
  $self = $(this),
  loopCount = 0,
  value = settings.from,
  data = $self.data('countTo') || {};
  $self.data('countTo', data);
  //如果有间断，找到并清除
  if (data.interval) {
    clearInterval(data.interval);
  };
  data.interval = setInterval(updateTimer, settings.refreshInterval);
  //初始化起始值
  render(value);
  function updateTimer() {
    value += increment;
    loopCount++;
    render(value);
    if (typeof(settings.onUpdate) == 'function') {
      settings.onUpdate.call(self, value);
    }
    if (loopCount >= loops) {
      //移出间隔
      $self.removeData('countTo');
      clearInterval(data.interval);
      value = settings.to;
      if (typeof(settings.onComplete) == 'function') {
        settings.onComplete.call(self, value);
      }
    }
  }
  function render(value) {
    var formattedValue = settings.formatter.call(self, value, settings);
    $self.html(formattedValue);
  }
  });
};
$.fn.countTo.defaults={
  from:0,               //数字开始的值
  to:0,                 //数字结束的值
  speed:1000,           //设置步长的时间
  refreshInterval:100,  //隔间值
  decimals:0,           //显示小位数
  formatter: formatter, //渲染之前格式化
  onUpdate:null,        //每次更新前的回调方法
  onComplete:null       //完成更新的回调方法
};
function formatter(value, settings){
  return value.toFixed(settings.decimals);
}
//自定义格式
$('.incrementing').data('countToOptions',{
  formmatter:function(value, options){
    return value.toFixed(options.decimals).replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
  }
});
//定时器
$('.incrementing').each(count);
function count(options){
  var $this=$(this);
  options=$.extend({}, options||{}, $this.data('countToOptions')||{});
  $this.countTo(options);
}