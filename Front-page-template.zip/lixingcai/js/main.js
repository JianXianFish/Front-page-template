// back to top
function goTop() {
    $('html,body').animate({'scrollTop': 0}, 1000);
}

$(window).scroll(function () {
    if ($(document).scrollTop() >= 200) {
        $('#backtop').addClass("show");
    } else {
        $('#backtop').removeClass("show");
    }
});
// mobile header nav dropdown-menu
$(document).on("click", ".mobile-navbtn", function (e) {
    $(this).toggleClass("open");
    $(this).parents("a").next(".dropdown-menu").toggleClass("open");
    e.preventDefault();
});

//swiper API move to -> http://www.swiper.com.cn/
var banner_swiper = new Swiper('#banner_swiper', {
    pagination: {
        el: '.swiper-pagination',
        clickable: true
    }
});
var product_swiper = new Swiper('.product_swiper', {
    slidesPerView: 3,	            //一屏显示多少个
    slidesPerColumn: 2,	          //显示2行
    spaceBetween: 20,
    observer: true,		            //修改swiper自己或子元素时，自动初始化swiper
    observeParents: true,	        //修改swiper的父元素时，自动初始化swiper
    breakpoints: {		            //响应式设置
        1200: {
            slidesPerView: 3
        },
        992: {
            slidesPerView: 2
        },
        768: {
            slidesPerView: 2
        },
        525: {
            slidesPerView: 1,
            slidesPerColumn: 1,
        }
    },
    pagination: {
        el: '.product_pagination',
        clickable: true
    }
});
var factory_swiper = new Swiper('#factory_swiper', {
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
    slidesPerView: 4,	            //一屏显示多少个
    slidesPerColumn: 1,	          //显示2行
    spaceBetween: 10,
    observer: true,		            //修改swiper自己或子元素时，自动初始化swiper
    observeParents: true,	        //修改swiper的父元素时，自动初始化swiper
    breakpoints: {
        992: {
            slidesPerView: 3
        },
        768: {
            slidesPerView: 2
        },
        525: {
            slidesPerView: 1,
        }
    }
});

var link_swiper = new Swiper('#link_swiper', {
    navigation: {
        nextEl: '#link_next',
        prevEl: ''
    },
    slidesPerView: 'auto',
});

var case_swiper = new Swiper('#case_swiper', {
    navigation: {
        nextEl: '.factory_swiper_next',
        prevEl: '.factory_swiper_prev'
    },
    breakpoints: {
        992: {
            slidesPerView: 3
        },
        350: {
            slidesPerView: 2
        }
    },
    slidesPerView: 4,
    spaceBetween: 20,
    on: {
        click: function (e) {
            $(case_swiper.clickedSlide).addClass('factory_active');
            $(case_swiper.clickedSlide).siblings().removeClass('factory_active');
            var $imgBox = $('#image_box .img_box');
            $imgBox.removeClass('active');
            $imgBox.eq(case_swiper.clickedIndex).addClass('active');
            var $giftBox = $('.gift_box_list .gift_box');
            $giftBox.removeClass('active');
            $giftBox.eq(case_swiper.clickedIndex).addClass('active');
        }
    }
});
var productIndex = 0;
var $tabli = $('#product_tab li');
$tabli.mouseenter(function (e) {
    e.stopPropagation();
    $tabli.removeClass('active');
    $(this).addClass('active');
});

$tabli.mouseleave(function (e) {
    e.stopPropagation();
    $tabli.removeClass('active');
    $tabli.eq(productIndex).addClass('active');
});
$tabli.each(function (index) {
    $(this).click(function (e) {
        productIndex = index;
        $tabli.removeClass('active');
        $tabli.eq(index).addClass('active');
        var $tabContent = $('#product_tab_content .tab_content_item');
        $tabContent.removeClass('active');
        $tabContent.eq(index).addClass('active');
    })
});
