console.log("%c                           ", "background-image: url(https://raw.githubusercontent.com/ZHAO-Shaofeng/Related-considerations-for-HTML-CSS-JS/master/github-img/xchl-logo.png);background-repeat: no-repeat;padding-top: 110px;");
console.log("%c技术支持：深圳市小草互联网科技有限公司，专注前端外包、美工外包。\n联系电话：13823771028\n淘宝店：https://shop269081662.taobao.com\n欢迎联系QQ/微信：364243821；并对我们的产品提出宝贵的意见和建议。\n为您服务，我们不胜荣幸！\n\n1.  根目录文件说明：\n    css | fonts | images | js | 页面（最终存放设计界面图片）；\n\n2.  所有icon图标一律引用阿里iconfont的线上图标。\nps：客户如需转交iconfont项目所有权，请与项目交付3天内联系我司。\nediter：赵少锋", "color: #0465c2;font-family: '微软雅黑';");

// back to top
function goTop() {
    $('html,body').animate({'scrollTop': 0}, 1000);
}

$(window).scroll(function () {
    if ($(document).scrollTop() >= 200) {
        $('#backtop').addClass("show");
    } else {
        $('#backtop').removeClass("show");
    }
});
// mobile header nav dropdown-menu
$(document).on("click", ".mobile-navbtn", function (e) {
    $(this).toggleClass("open");
    $(this).parents("a").next(".dropdown-menu").toggleClass("open");
    e.preventDefault();
})

//swiper API move to -> http://www.swiper.com.cn/
new Swiper('#banner_swiper', {
    navigation: {		              //前进后退按钮
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev'
    },
    observer: true,		            //修改swiper自己或子元素时，自动初始化swiper
    observeParents: true,
});


new Swiper('.product_swiper', {
    pagination: {
        el: '.swiper-pagination',
        clickable: true
    },
    slidesPerView: 4,	            //一屏显示多少个
    slidesPerColumn: 2,	          //显示2行
    spaceBetween: 10,
    observer: true,		            //修改swiper自己或子元素时，自动初始化swiper
    observeParents: true,
    breakpoints: {		            //响应式设置
        1200: {
            slidesPerView: 4,
            slidesPerColumn: 2,
            spaceBetween: 35
        },
        992: {
            slidesPerView: 3,
            slidesPerColumn: 2,
            spaceBetween: 35
        },
        768: {
            slidesPerView: 2,
            slidesPerColumn: 2,
            spaceBetween: 35
        },
        510: {
            slidesPerView: 1,
            slidesPerColumn: 1,
            spaceBetween: 35
        }
    }
});

new Swiper('#product2_swiper', {
    pagination: {
        el: '.swiper-pagination',
        clickable: true
    },
    slidesPerView: 5,	            //一屏显示多少个
    spaceBetween: 30,
    observer: true,		            //修改swiper自己或子元素时，自动初始化swiper
    observeParents: true,
    breakpoints: {		            //响应式设置
        1200: {
            slidesPerView: 4
        },
        992: {
            slidesPerView: 3
        },
        768: {
            slidesPerView: 2
        },
        510: {
            slidesPerView: 1
        }
    }
});
new Swiper('#news_swiper', {
    pagination: {
        el: '.swiper-pagination',
        clickable: true
    },
    slidesPerView: 2,	            //一屏显示多少个
    slidesPerColumn: 2,	          //显示2行
    spaceBetween: 16,
    slidesPerColumnFill: 'row',
    observer: true,		            //修改swiper自己或子元素时，自动初始化swiper
    observeParents: true,
    breakpoints: {		            //响应式设置
        1200: {
            slidesPerView: 1,
            slidesPerColumn: 2
        },
        768: {
            slidesPerView: 1,
            slidesPerColumn: 1
        },
        510: {
            slidesPerView: 1,
            slidesPerColumn: 1
        }
    }
});

new Swiper('#case_swiper', {
    pagination: {
        el: '.swiper-pagination',
        clickable: true
    },
    slidesPerView: 3,
    spaceBetween: 35,
    observer: true,		            //修改swiper自己或子元素时，自动初始化swiper
    observeParents: true,
    breakpoints: {		            //响应式设置
        991: {
            slidesPerView: 2,
            spaceBetween: 35
        },
        625: {
            slidesPerView: 1,
            spaceBetween: 35
        }
    }
});

var application_swiper = new Swiper('#application_swiper', {
    // navigation: {		              //前进后退按钮
    //     nextEl: '.application_next',
    //     prevEl: '.application_prev'
    // },
    initialSlide: 1,
    loop: true,
    slidesPerView: 2,
    spaceBetween: 25,
    observer: true,		            //修改swiper自己或子元素时，自动初始化swiper
    observeParents: true,
    breakpoints: {		            //响应式设置
        991: {
            slidesPerView: 2
        },
        767: {
            slidesPerView: 1
        }
    }
});

$('.application_prev').click(function (e) {
    application_swiper.slidePrev();
});
$('.application_next').click(function (e) {
    application_swiper.slideNext();
});


new Swiper('#certificate_swiper', {
    navigation: {		              //前进后退按钮
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev'
    },
    slidesPerView: 2,	           //显示2行
    spaceBetween: 15,
    observer: true,		            //修改swiper自己或子元素时，自动初始化swiper
    observeParents: true,
    breakpoints: {		            //响应式设置
        1200: {
            slidesPerView: 1,
            spaceBetween: 15
        },
        992: {
            slidesPerView: 1,
            spaceBetween: 15
        }
    }
});


$('.product_tab').each(function (index) {
    $(this).click(function (e) {
        $(this).siblings().removeClass('active');
        $(this).addClass('active');
        $('.tab_content_item').removeClass('active');
        $('.tab_content_item').eq(index).addClass('active')
    })
});
